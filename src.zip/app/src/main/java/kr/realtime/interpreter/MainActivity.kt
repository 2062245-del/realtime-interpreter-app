package kr.realtime.interpreter

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.lang.ref.WeakReference

/**
 * 실시간 통역기 앱
 * - 화면(UI)과 통역 로직은 웹 도구와 '같은 코드'를 그대로 불러와 사용 → 웹을 개선하면 앱에도 자동 반영
 * - 음성 인식 / 음성 출력 / 진동 / 백그라운드 듣기는 안드로이드 기능(Bridge)으로 제공
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val WEB_URL = "https://realtime-interpreter-kr.netlify.app/?app=android"
        const val OFFLINE_URL = "file:///android_asset/index.html"
        const val REQ_MIC = 101
        var current: WeakReference<MainActivity>? = null
    }

    lateinit var web: WebView
    lateinit var bridge: Bridge
    private var loadedFallback = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0d0f14"))
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.textZoom = 100

        bridge = Bridge(this, web)
        web.addJavascriptInterface(bridge, "AndroidBridge")

        web.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                // 인터넷이 안 되면 앱에 내장된 사본으로 실행
                if (request.isForMainFrame && !loadedFallback) {
                    loadedFallback = true
                    view.loadUrl(OFFLINE_URL)
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else moveTaskToBack(true) // 뒤로가기 = 앱을 끄지 않고 뒤로 숨기기
            }
        })

        web.loadUrl(WEB_URL)
    }

    /** 앱이 뒤로 가도 WebView의 통역 로직이 멈추지 않도록 일시정지하지 않음 */
    override fun onPause() {
        super.onPause()
        web.resumeTimers()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.resumeTimers()
    }

    override fun onDestroy() {
        bridge.release()
        current = null
        super.onDestroy()
    }

    fun setKeepScreen(on: Boolean) {
        runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    fun requestMicPermission() {
        val need = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) { bridge.js("window.__nb&&__nb.mic(true)"); return }
        ActivityCompat.requestPermissions(this, need.toTypedArray(), REQ_MIC)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            val ok = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            bridge.js("window.__nb&&__nb.mic($ok)")
        }
    }

    /** 알림창의 '끄기' 버튼 → 웹 쪽 상시 대기 끄기 */
    fun stopStandbyFromNotification() {
        bridge.js("(function(){var b=document.getElementById('cStart');if(b&&document.getElementById('viewC').classList.contains('cOn'))b.click();})()")
    }
}
