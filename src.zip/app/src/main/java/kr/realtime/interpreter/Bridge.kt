package kr.realtime.interpreter

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * 웹 코드(JS)가 부르는 안드로이드 기능 모음.
 * JS 쪽에서는 표준 SpeechRecognition / speechSynthesis / navigator.vibrate 와 똑같은 모양으로 감싸서 사용.
 */
class Bridge(private val act: MainActivity, private val web: WebView) {

    private val main = Handler(Looper.getMainLooper())
    private val audio = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---------- JS 호출 ----------
    fun js(code: String) { main.post { try { web.evaluateJavascript(code, null) } catch (_: Exception) {} } }
    private fun q(s: String) = JSONObject.quote(s)

    // ---------- 음성 인식 ----------
    private var recognizer: SpeechRecognizer? = null
    private var curId = 0
    private var curLang = "ko-KR"
    private var continuous = false
    private var interim = true
    private var stopping = false
    private var restartCount = 0

    @JavascriptInterface
    fun srStart(id: Int, lang: String, cont: Boolean, partial: Boolean) {
        main.post {
            // 이전 세션 정리
            if (curId != 0 && curId != id) { val old = curId; curId = 0; try { recognizer?.cancel() } catch (_: Exception) {}; emitSr(old, "end", null) }
            curId = id; curLang = lang; continuous = cont; interim = partial; stopping = false; restartCount = 0
            listen()
        }
    }

    @JavascriptInterface fun srStop(id: Int) { main.post { if (id == curId) { stopping = true; try { recognizer?.stopListening() } catch (_: Exception) {} } } }

    @JavascriptInterface fun srAbort(id: Int) {
        main.post { if (id == curId) { stopping = true; curId = 0; try { recognizer?.cancel() } catch (_: Exception) {}; emitSr(id, "end", null) } }
    }

    private fun emitSr(id: Int, type: String, payload: JSONObject?) {
        js("window.__nb&&__nb.sr($id,${q(type)},${if (payload == null) "null" else q(payload.toString())})")
    }

    private fun ensureRecognizer(): SpeechRecognizer? {
        if (recognizer == null) {
            if (!SpeechRecognizer.isRecognitionAvailable(act)) return null
            recognizer = SpeechRecognizer.createSpeechRecognizer(act)
            recognizer?.setRecognitionListener(listener)
        }
        return recognizer
    }

    private fun listen() {
        val id = curId
        val r = ensureRecognizer()
        if (r == null) { emitSr(id, "error", JSONObject().put("error", "service-not-allowed")); emitSr(id, "end", null); curId = 0; return }
        val it = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, curLang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, curLang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, interim)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, act.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        muteBeep()
        try { r.startListening(it) } catch (e: Exception) {
            emitSr(id, "error", JSONObject().put("error", "aborted")); emitSr(id, "end", null); curId = 0
        }
    }

    /** 인식 시작 때 나는 '띵' 소리를 잠깐 음소거 (음성 출력 중이 아닐 때만) */
    private fun muteBeep() {
        val streams = mutableListOf(AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM)
        if (!ttsSpeaking) streams.add(AudioManager.STREAM_MUSIC)
        try {
            streams.forEach { audio.adjustStreamVolume(it, AudioManager.ADJUST_MUTE, 0) }
            main.postDelayed({ streams.forEach { s -> try { audio.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {} } }, 600)
        } catch (_: Exception) {}
    }

    private fun restartOrEnd() {
        val id = curId
        if (id == 0) return
        if (continuous && !stopping) {
            restartCount++
            main.postDelayed({ if (curId == id && !stopping) listen() }, if (restartCount > 20) 400 else 80)
        } else {
            curId = 0
            emitSr(id, "end", null)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            if (t.isBlank() || curId == 0) return
            emitSr(curId, "result", JSONObject().put("text", t).put("final", false).put("conf", 0))
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val conf = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
            val t = list?.firstOrNull()
            if (!t.isNullOrBlank() && curId != 0) {
                emitSr(curId, "result", JSONObject().put("text", t).put("final", true)
                    .put("conf", if (conf != null && conf.isNotEmpty() && conf[0] >= 0) conf[0].toDouble() else 0.0))
            }
            restartOrEnd()
        }

        override fun onError(error: Int) {
            val id = curId
            if (id == 0) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restartOrEnd()   // 조용함 → 계속 듣기
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> main.postDelayed({ if (curId == id) { try { recognizer?.cancel() } catch (_: Exception) {}; listen() } }, 300)
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { emitSr(id, "error", JSONObject().put("error", "not-allowed")); curId = 0; emitSr(id, "end", null) }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> {
                    emitSr(id, "error", JSONObject().put("error", "network"))
                    if (continuous && !stopping) main.postDelayed({ if (curId == id) listen() }, 1500) else { curId = 0; emitSr(id, "end", null) }
                }
                SpeechRecognizer.ERROR_AUDIO -> {
                    emitSr(id, "error", JSONObject().put("error", "audio-capture"))
                    if (continuous && !stopping) main.postDelayed({ if (curId == id) listen() }, 1500) else { curId = 0; emitSr(id, "end", null) }
                }
                else -> {
                    // 기타 오류는 인식기를 새로 만들어 재시도
                    try { recognizer?.destroy() } catch (_: Exception) {}
                    recognizer = null
                    if (continuous && !stopping) main.postDelayed({ if (curId == id) listen() }, 500) else { curId = 0; emitSr(id, "end", null) }
                }
            }
        }
    }

    // ---------- 음성 출력 ----------
    @Volatile private var ttsSpeaking = false
    private var ttsReady = false
    private val pending = mutableListOf<() -> Unit>()
    private val tts: TextToSpeech = TextToSpeech(act) { status ->
        ttsReady = status == TextToSpeech.SUCCESS
        main.post { pending.forEach { it() }; pending.clear(); js("window.__nb&&__nb.voices()") }
    }.also {
        it.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { ttsSpeaking = true; js("window.__nb&&__nb.tts(${utteranceId ?: 0},'start')") }
            override fun onDone(utteranceId: String?) { ttsSpeaking = false; js("window.__nb&&__nb.tts(${utteranceId ?: 0},'end')") }
            @Deprecated("") override fun onError(utteranceId: String?) { ttsSpeaking = false; js("window.__nb&&__nb.tts(${utteranceId ?: 0},'error')") }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { ttsSpeaking = false; js("window.__nb&&__nb.tts(${utteranceId ?: 0},'end')") }
        })
    }

    @JavascriptInterface
    fun ttsSpeak(id: Int, text: String, lang: String, rate: Double, pitch: Double, volume: Double, voiceName: String) {
        val job = {
            try {
                val v = if (voiceName.isNotEmpty()) tts.voices?.firstOrNull { it.name == voiceName } else null
                if (v != null) tts.setVoice(v) else if (lang.isNotEmpty()) tts.setLanguage(Locale.forLanguageTag(lang))
                tts.setSpeechRate(rate.toFloat())
                tts.setPitch(pitch.toFloat())
                val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.toFloat()) }
                tts.speak(text, TextToSpeech.QUEUE_ADD, params, id.toString())
            } catch (e: Exception) { js("window.__nb&&__nb.tts($id,'error')") }
            Unit
        }
        main.post { if (ttsReady) job() else pending.add(job) }
    }

    @JavascriptInterface fun ttsStop() { main.post { try { tts.stop() } catch (_: Exception) {}; ttsSpeaking = false } }

    @JavascriptInterface
    fun ttsVoices(): String {
        val arr = JSONArray()
        try {
            tts.voices?.sortedBy { it.name }?.forEach { v ->
                arr.put(JSONObject().put("name", v.name).put("lang", v.locale.toLanguageTag())
                    .put("voiceURI", v.name).put("localService", !v.isNetworkConnectionRequired))
            }
        } catch (_: Exception) {}
        return arr.toString()
    }

    // ---------- 진동 / 화면 / 권한 ----------
    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun vibrate(patternJson: String) {
        try {
            val a = JSONArray(patternJson)
            val pattern = LongArray(a.length() + 1)
            pattern[0] = 0
            for (i in 0 until a.length()) pattern[i + 1] = a.getLong(i)
            val vib: Vibrator = if (Build.VERSION.SDK_INT >= 31)
                (act.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            else act.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vib.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (_: Exception) {}
    }

    @JavascriptInterface fun keepScreen(on: Boolean) = act.setKeepScreen(on)
    @JavascriptInterface fun requestMic() { main.post { act.requestMicPermission() } }
    @JavascriptInterface fun isApp(): Boolean = true

    // ---------- 백그라운드 듣기 (알림창 상주) ----------
    @JavascriptInterface
    fun bgStart(title: String, text: String) {
        main.post {
            val i = Intent(act, ListenService::class.java).putExtra("title", title).putExtra("text", text)
            try { ContextCompat.startForegroundService(act, i); js("window.__nb&&__nb.bg('on')") } catch (_: Exception) {}
        }
    }

    @JavascriptInterface
    fun bgStop() { main.post { try { act.stopService(Intent(act, ListenService::class.java)) } catch (_: Exception) {}; js("window.__nb&&__nb.bg('off')") } }

    // ---------- 파일 저장 (용어사전 내보내기) ----------
    @JavascriptInterface
    fun saveFile(name: String, content: String) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            }
            if (Build.VERSION.SDK_INT >= 29) {
                val uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
                act.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
            }
        } catch (_: Exception) {}
    }

    fun release() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        try { tts.shutdown() } catch (_: Exception) {}
    }
}
